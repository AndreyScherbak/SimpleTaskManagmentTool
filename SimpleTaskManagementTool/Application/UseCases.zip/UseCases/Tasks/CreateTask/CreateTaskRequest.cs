﻿namespace Application.UseCases.Tasks.CreateTask
{
    /// <summary>
    /// Data the caller must supply when creating a new task.
    /// </summary>
    /// <param name="BoardId">The aggregate root (board) the task belongs to.</param>
    /// <param name="Title">The task’s title. Must pass <see cref="Validators.TaskTitleValidator"/>.</param>
    /// <param name="DueDate">Optional due-date in UTC.  Must be in the future (see <see cref="Validators.DueDateValidator"/>).</param>
    public sealed record CreateTaskRequest(Guid BoardId, string Title, DateTime? DueDate);
}
